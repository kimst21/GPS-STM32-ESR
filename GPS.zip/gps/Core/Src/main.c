/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : GPS 데이터 수신 및 디스플레이 프로그램
  ******************************************************************************
  * @attention
  * - GPS 모듈로부터 UART로 데이터를 수신합니다.
  * - 수신된 NMEA 형식 데이터를 파싱하여 위도와 경도를 SSD1306 OLED 디스플레이에 출력합니다.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"        // STM32 초기화 관련 헤더
#include "i2c.h"         // I2C 초기화 및 제어 관련 헤더
#include "usart.h"       // UART 초기화 및 제어 관련 헤더
#include "gpio.h"        // GPIO 설정 및 제어 관련 헤더

/* USER CODE BEGIN Includes */
#include <string.h>      // 문자열 처리 라이브러리
#include <stdio.h>       // 입출력 처리 라이브러리
#include "fonts.h"       // SSD1306 디스플레이용 글꼴
#include "ssd1306.h"     // SSD1306 디스플레이 제어 라이브러리
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
char strCopy[15];                  // 문자열 출력용 버퍼
uint8_t rxBuffer[128] = {0};       // UART 수신 버퍼
uint8_t rxIndex = 0;               // UART 수신 데이터 인덱스
uint8_t rxData;                    // UART 수신 데이터
float nmeaLong;                    // NMEA 경도 데이터
float nmeaLat;                     // NMEA 위도 데이터
float utcTime;                     // UTC 시간
char northsouth;                   // 북/남 방향
char eastwest;                     // 동/서 방향
char posStatus;                    // 위치 상태
float decimalLong;                 // 경도 (십진수)
float decimalLat;                  // 위도 (십진수)
/* USER CODE END PV */

/* USER CODE BEGIN 0 */
/**
  * @brief  NMEA 데이터를 십진수로 변환
  * @param  coordinate : NMEA 형식의 위도 또는 경도 값
  * @retval float : 십진수 형식의 위도 또는 경도 값
  */
float nmeaToDecimal(float coordinate) {
    int degree = (int)(coordinate / 100); // 도수 부분 추출
    float minutes = coordinate - degree * 100; // 분수 부분 추출
    float decimalDegree = minutes / 60; // 분을 도로 변환
    float decimal = degree + decimalDegree;
    return decimal;
}

/**
  * @brief  NMEA 데이터 파싱
  * @param  strParse : NMEA 형식의 문자열
  */
void gpsParse(char *strParse) {
    if (!strncmp(strParse, "$GPGGA", 6)) { // GPGGA 데이터 파싱
        sscanf(strParse, "$GPGGA,%f,%f,%c,%f,%c",
            &utcTime, &nmeaLat, &northsouth, &nmeaLong, &eastwest);
        decimalLat = nmeaToDecimal(nmeaLat);
        decimalLong = nmeaToDecimal(nmeaLong);
    } else if (!strncmp(strParse, "$GPGLL", 6)) { // GPGLL 데이터 파싱
        sscanf(strParse, "$GPGLL,%f,%c,%f,%c,%f",
            &nmeaLat, &northsouth, &nmeaLong, &eastwest, &utcTime);
        decimalLat = nmeaToDecimal(nmeaLat);
        decimalLong = nmeaToDecimal(nmeaLong);
    } else if (!strncmp(strParse, "$GPRMC", 6)) { // GPRMC 데이터 파싱
        sscanf(strParse, "$GPRMC,%f,%c,%f,%c,%f,%c",
            &utcTime, &posStatus, &nmeaLat, &northsouth, &nmeaLong, &eastwest);
        decimalLat = nmeaToDecimal(nmeaLat);
        decimalLong = nmeaToDecimal(nmeaLong);
    }
}

/**
  * @brief  NMEA 데이터 체크섬 유효성 검증
  * @param  nmea : NMEA 데이터 문자열
  * @retval int : 유효하면 1, 아니면 0
  */
int gpsValidate(char *nmea) {
    char check[3];
    char calculatedString[3];
    int index = 0;
    int calculatedCheck = 0;

    // 문자열이 '$'로 시작하지 않으면 유효하지 않음
    if (nmea[index] != '$') return 0;
    index++;

    // '*' 문자 전까지 체크섬 계산
    while ((nmea[index] != 0) && (nmea[index] != '*') && (index < 75)) {
        calculatedCheck ^= nmea[index];
        index++;
    }

    // 유효성 확인
    if (nmea[index] == '*') {
        check[0] = nmea[index + 1];
        check[1] = nmea[index + 2];
        check[2] = 0;
    } else {
        return 0;
    }

    sprintf(calculatedString, "%02X", calculatedCheck);
    return ((calculatedString[0] == check[0]) && (calculatedString[1] == check[1])) ? 1 : 0;
}

/**
  * @brief  UART 수신 인터럽트 콜백
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART1) {
        if (rxData != '\n' && rxIndex < sizeof(rxBuffer)) { // '\n' 이전까지 수신 데이터 저장
            rxBuffer[rxIndex++] = rxData;
        } else {
            if (gpsValidate((char *)rxBuffer)) gpsParse((char *)rxBuffer); // 유효성 확인 후 파싱
            rxIndex = 0;
            memset(rxBuffer, 0, sizeof(rxBuffer));
        }
        HAL_UART_Receive_IT(&huart1, &rxData, 1); // 인터럽트 수신 다시 활성화
    }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  HAL_Init();                      // HAL 라이브러리 초기화
  SystemClock_Config();            // 시스템 클럭 설정
  MX_GPIO_Init();                  // GPIO 초기화
  MX_I2C3_Init();                  // I2C 초기화 (SSD1306 디스플레이 통신용)
  MX_USART1_UART_Init();           // UART 초기화 (GPS 데이터 수신용)
  SSD1306_Init();                  // SSD1306 OLED 초기화

  HAL_UART_Receive_IT(&huart1, &rxData, 1); // UART 인터럽트 수신 활성화

  while (1) {
      uint16_t Long, Lat;
      Long = (uint16_t)decimalLong;
      Lat = (uint16_t)decimalLat;

      SSD1306_Clear();
      SSD1306_GotoXY(0, 0);
      sprintf(strCopy, "Longi: %d", Long); // 경도 출력
      SSD1306_Puts(strCopy, &Font_11x18, 1);

      SSD1306_GotoXY(0, 20);
      sprintf(strCopy, "Lati: %d", Lat);   // 위도 출력
      SSD1306_Puts(strCopy, &Font_11x18, 1);

      SSD1306_UpdateScreen(); // OLED 화면 갱신
      HAL_Delay(1000);
  }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
