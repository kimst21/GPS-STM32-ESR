/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : GPS 데이터를 수신하고 OLED에 출력하는 프로그램
  ******************************************************************************
  * @attention
  * - GPS 모듈에서 UART로 데이터를 수신하여 분석합니다.
  * - NMEA 데이터를 파싱하여 SSD1306 OLED에 위도/경도를 표시합니다.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
#include <string.h>      // 문자열 처리 라이브러리
#include <stdio.h>       // 입출력 처리를 위한 라이브러리
#include "fonts.h"       // SSD1306 폰트 라이브러리
#include "ssd1306.h"     // SSD1306 OLED 제어 라이브러리

/* Private variables ---------------------------------------------------------*/
char strCopy[20];                 // OLED 출력 버퍼
uint8_t rxBuffer[128] = {0};      // UART 수신 버퍼
uint8_t rxIndex = 0;              // 수신 데이터 위치
uint8_t rxData;                   // 단일 바이트 수신 데이터
float nmeaLong, nmeaLat, utcTime; // NMEA 위도, 경도 및 UTC 시간
char northsouth, eastwest, posStatus; // 위도/경도 방향 및 GPS 상태
float decimalLong, decimalLat;    // 십진수 변환된 위도, 경도 값

/* Function prototypes */
void SystemClock_Config(void);
void gpsParse(char *strParse);
int gpsValidate(char *nmea);

/**
  * @brief  NMEA 형식의 좌표 데이터를 십진수로 변환하는 함수
  * @param  coordinate : NMEA 형식의 위도/경도 데이터
  * @retval float : 변환된 십진수 위도/경도 값
  */
float nmeaToDecimal(float coordinate) {
    int degree = (int)(coordinate / 100); // 도(Degree) 추출
    float minutes = coordinate - (degree * 100); // 분(Minutes) 추출
    return degree + (minutes / 60); // 십진수 변환
}

/**
  * @brief  NMEA 데이터를 파싱하여 위도와 경도를 추출하는 함수
  * @param  strParse : 수신된 NMEA 문자열
  */
void gpsParse(char *strParse) {
    printf("Parsing: %s\r\n", strParse); // 디버깅 출력

    // $GNGGA 또는 $GPGGA 문장 파싱
    if (strstr(strParse, "$GNGGA")) {
        sscanf(strParse, "$GNGGA,%f,%f,%c,%f,%c",
            &utcTime, &nmeaLat, &northsouth, &nmeaLong, &eastwest);
    }
    // $GPGGA 문장 파싱
    else if (strstr(strParse, "$GPGGA")) {
        sscanf(strParse, "$GPGGA,%f,%c,%f,%c,%f",
            &nmeaLat, &northsouth, &nmeaLong, &eastwest, &utcTime);
    }
    // $GPGLL 문장 파싱
    else if (strstr(strParse, "$GPGLL")) {
        sscanf(strParse, "$GPGLL,%f,%c,%f,%c,%f",
            &nmeaLat, &northsouth, &nmeaLong, &eastwest, &utcTime);
    }
    // $GPRMC 문장 파싱
    else if (strstr(strParse, "$GPRMC")) {
        sscanf(strParse, "$GPRMC,%f,%c,%f,%c,%f,%c",
            &utcTime, &posStatus, &nmeaLat, &northsouth, &nmeaLong, &eastwest);
    }
    else {
        printf("Unknown GPS format\r\n");
        return;
    }

    // NMEA 좌표를 십진수 좌표로 변환
    decimalLat = nmeaToDecimal(nmeaLat);
    decimalLong = nmeaToDecimal(nmeaLong);
}

/**
  * @brief  NMEA 데이터의 체크섬을 검증하는 함수
  * @param  nmea : 수신된 NMEA 데이터 문자열
  * @retval int : 유효하면 1, 아니면 0 반환
  */
int gpsValidate(char *nmea) {
    char check[3], calculatedString[3];
    int index = 0, calculatedCheck = 0;

    if (nmea[index] != '$') return 0; // NMEA 데이터는 반드시 '$'로 시작해야 함
    index++;

    // '*' 전까지 XOR 체크섬 계산
    while ((nmea[index] != 0) && (nmea[index] != '*') && (index < 75)) {
        calculatedCheck ^= nmea[index];
        index++;
    }

    // 원본 체크섬 값 비교
    if (nmea[index] == '*') {
        check[0] = nmea[index + 1];
        check[1] = nmea[index + 2];
        check[2] = 0;
    } else return 0;

    sprintf(calculatedString, "%02X", calculatedCheck);
    return ((calculatedString[0] == check[0]) && (calculatedString[1] == check[1])) ? 1 : 0;
}

/**
  * @brief  UART 인터럽트 수신 콜백 함수
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART1) {
        if (rxData != '\n' && rxIndex < sizeof(rxBuffer) - 1) {
            rxBuffer[rxIndex++] = rxData;
        } else {
            rxBuffer[rxIndex] = '\0'; // 문자열 종료

            // UART로 수신된 데이터 디버깅 출력
            printf("Received: %s\r\n", rxBuffer);

            if (gpsValidate((char *)rxBuffer)) {
                gpsParse((char *)rxBuffer);
            } else {
                printf("Invalid GPS data\r\n");
            }

            rxIndex = 0;
            memset(rxBuffer, 0, sizeof(rxBuffer));
        }
        HAL_UART_Receive_IT(&huart1, &rxData, 1);
    }
}

/**
  * @brief  메인 함수
  */
int main(void) {
    HAL_Init();
    SystemClock_Config();

    /* 주변 장치 초기화 */
    MX_GPIO_Init();
    MX_I2C3_Init();
    MX_USART1_UART_Init();

    /* SSD1306 OLED 초기화 */
    SSD1306_Init();
    HAL_UART_Receive_IT(&huart1, &rxData, 1);

    while (1) {
        /* OLED 화면 업데이트 */
        SSD1306_Clear();
        SSD1306_GotoXY(0, 0);

        // GPS 데이터가 정상적으로 수신되었을 경우 OLED 출력
        if (decimalLong != 0.0 && decimalLat != 0.0) {
            sprintf(strCopy, "Long: %.1f", decimalLong);
            SSD1306_Puts(strCopy, &Font_11x18, 1);

            SSD1306_GotoXY(0, 20);
            sprintf(strCopy, "Lat : %.1f", decimalLat);
            SSD1306_Puts(strCopy, &Font_11x18, 1);
        } else {
            SSD1306_Puts("GPS WAIT...", &Font_11x18, 1);
        }

        SSD1306_UpdateScreen();
        HAL_Delay(1000);
    }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
